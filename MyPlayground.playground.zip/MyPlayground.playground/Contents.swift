import UIKit

var eevee = "eevee"
let pikachu = "pikachuuu"
var pokemon: [String] = []
pokemon.append(eevee)
pokemon.append(pikachu)
pokemon.insert("Jolteon",at:0)
pokemon.remove(at: 0)
print(pokemon)
