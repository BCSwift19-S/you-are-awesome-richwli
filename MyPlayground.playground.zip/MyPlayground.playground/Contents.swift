import UIKit

var str = "Hello, playground"
var eevee = "eevee"
let pikachu = "pikachuuu"
eevee = "eevee!!!"
