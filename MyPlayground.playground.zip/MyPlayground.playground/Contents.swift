import UIKit
var count = Int.random(in: 0..<5)
for i in 0..<5{
    if(i==count){
    print("Count and i is equal at: \(count)")
    }
}
var adjective = ""
for i in 0...6{
    adjective = adjective + " really"
}

print("I am "+adjective+" happy.")


for i in stride(from:100,to:0,by:-4){
    print("countdown is: \(i)")
}
print("Blastoff!!!")
