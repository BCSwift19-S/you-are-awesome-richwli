import UIKit

var int1 = 5
var int2 = 10
var int3 = 5*10
var int4 = int1*(int2)
var float1 = (5)/10.0


